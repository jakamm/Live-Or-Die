﻿using UnityEngine;
using EmeraldAI;

namespace ThunderWire.EmeraldAI
{
    public class EmeralAISendDamage : MonoBehaviour
    {
        /// <summary>
        /// Send Damage to Emerald AI System
        /// </summary>
        public void ApplyDamage(int DamageAmount)
        {
            EmeraldAISystem EmeraldComponent = GetComponent<EmeraldAISystem>();

            //Cause damage to the AI that is hit using the HFPS damage function.
            EmeraldComponent.Damage(DamageAmount, EmeraldAISystem.TargetType.Player, transform, 400);
        }
    }
}